# ZeDMD 5.1.7 — 128×32 Flash Only

This is the **flash step only**, extracted from the known-working `batocera-zedmd-marquee-v3.0` package.

It downloads:
- Official ZeDMD **5.1.7** `ZeDMD-128x32.zip`
- Espressif `esptool` **4.8.1** Linux x86_64 binary

It then flashes the official `ZeDMD.bin` to the ESP32 at `0x0`.

## Requirements

- Batocera / Linux x86_64
- Internet access
- `curl`
- `unzip`
- ESP32 connected over USB

## Flash

```bash
cd /userdata/zedmd-5.1.7-128x32-flash-only
chmod +x flash-zedmd.sh
PORT=/dev/ttyUSB0 ./flash-zedmd.sh
```

If exactly one `/dev/ttyUSB*` or `/dev/ttyACM*` device exists, `PORT=` can be omitted.

Type:

```text
ZEDMD
```

when prompted.

## After Flashing

On the ZeDMD setup screen:

1. Set **Transport = USB**
2. Set **USB packet size = 512** if exposed in the setup UI
3. Confirm the panel is **128×32**
4. Navigate to **Exit**

Then install the separate combined Batocera runtime package.

> This package intentionally contains no custom boot firmware, PlatformIO, Git, WLED, or experimental firmware changes.
