#!/bin/bash
set -Eeuo pipefail
BASE="/userdata/system/zedmd-marquee"
TOOLS="$BASE/tools"
FWVER="5.1.7"
FWURL="https://github.com/PPUC/ZeDMD/releases/download/v${FWVER}/ZeDMD-128x32.zip"
ESPVER="4.8.1"
ESPURL="https://github.com/espressif/esptool/releases/download/v${ESPVER}/esptool-v${ESPVER}-linux-amd64.zip"
mkdir -p "$TOOLS"; cd "$TOOLS"

[ "$(uname -m)" = "x86_64" ] || { echo "This helper targets the x86_64 Retro Lunatics build."; exit 1; }

detect_port() {
  [ -n "${PORT:-}" ] && { echo "$PORT"; return; }
  local p=()
  shopt -s nullglob; p+=(/dev/ttyUSB* /dev/ttyACM*); shopt -u nullglob
  [ "${#p[@]}" -eq 1 ] && { echo "${p[0]}"; return; }
  echo ""
}
SERIAL="$(detect_port)"
[ -n "$SERIAL" ] || { echo "Set the ESP32 explicitly, e.g. PORT=/dev/ttyUSB0 $0"; exit 1; }

[ -f ZeDMD-128x32.zip ] || curl -fL --retry 3 -o ZeDMD-128x32.zip "$FWURL"
rm -rf fw; mkdir fw; unzip -o ZeDMD-128x32.zip -d fw >/dev/null
BIN="$(find fw -name ZeDMD.bin -type f | head -n1)"
[ -n "$BIN" ] || { echo "ZeDMD.bin not found"; exit 1; }

[ -f "esptool-v${ESPVER}-linux-amd64.zip" ] || curl -fL --retry 3 -o "esptool-v${ESPVER}-linux-amd64.zip" "$ESPURL"
rm -rf esptool-linux-amd64
unzip -o "esptool-v${ESPVER}-linux-amd64.zip" >/dev/null
chmod +x ./esptool-linux-amd64/esptool

echo
echo "This replaces the current WLED firmware on $SERIAL with official ZeDMD $FWVER."
if [ "${YES:-0}" != "1" ]; then
  read -r -p "Type ZEDMD to continue: " A
  [ "$A" = "ZEDMD" ] || exit 1
fi

batocera-services stop dmd_real 2>/dev/null || true
./esptool-linux-amd64/esptool --port "$SERIAL" --chip esp32 write_flash 0x0 "$BIN"
sleep 4
echo
echo "Flash complete. On the ZeDMD setup screen select Transport: USB, then navigate to Exit."
