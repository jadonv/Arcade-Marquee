#!/bin/bash
set -Eeuo pipefail

SRC="$(cd "$(dirname "$0")" && pwd)"
BASE="/userdata/system/zedmd-marquee"
ES="/userdata/system/configs/emulationstation/scripts"
CUSTOM="/userdata/system/custom.sh"

echo "===================================================="
echo " ZeDMD Marquee - Known Working Combined Installer"
echo " v3.0 base + v3.2.1 animations"
echo "===================================================="
echo
echo "This installer DOES NOT flash the ESP32."
echo "Flash ZeDMD 5.1.7 128x32 first with the separate flash package."
echo

mkdir -p "$BASE/user-animations"
cp -f "$SRC/config.json" "$BASE/config.json"
cp -f "$SRC/scripts/"*.sh "$BASE/"
chmod +x "$BASE/"*.sh

# Preserve user-supplied GIFs.
if [ -d "$SRC/user-animations" ]; then
  find "$SRC/user-animations" -maxdepth 1 -type f -iname '*.gif' -exec cp -n {} "$BASE/user-animations/" \; 2>/dev/null || true
fi

# Remove the old custom WLED/USB hooks exactly as v3.0 did.
for E in game-selected system-selected game-start game-end quit shutdown reboot screensaver-start achievements; do
  mkdir -p "$ES/$E"
  rm -f "$ES/$E/20-wled-marquee.sh" "$ES/$E/20-usb-marquee.sh" "$ES/$E/dmd-simulator.sh"
done
[ -x /userdata/system/wled-marquee/marquee_daemon.py ] && /userdata/system/wled-marquee/marquee_daemon.py stop 2>/dev/null || true
[ -x /userdata/system/wled-marquee/marquee_usb_daemon.py ] && /userdata/system/wled-marquee/marquee_usb_daemon.py stop 2>/dev/null || true

echo "[1/6] Installing/checking Pixelcade artwork..."
"$BASE/artwork-update.sh" --check || true

echo "[2/6] Syncing artwork into Batocera native DMD paths..."
"$BASE/sync-artwork.sh" || true

echo "[3/6] Enabling native dmd_real..."
batocera-services enable dmd_real 2>/dev/null || true
batocera-services start dmd_real 2>/dev/null || true

echo "[4/6] Applying known-working ZeDMD settings (512-byte USB / 60 Hz)..."
"$BASE/configure-zedmd.sh" || true

echo "[5/6] Installing v3.2.1 animation hooks..."
for EVENT in shutdown quit; do
  mkdir -p "$ES/$EVENT"
  cp -f "$SRC/events/$EVENT/30-zedmd-shutdown-animation.sh" "$ES/$EVENT/"
  chmod +x "$ES/$EVENT/30-zedmd-shutdown-animation.sh"
done
"$BASE/configure-animations.sh" || true

echo "[6/6] Installing boot hooks..."
touch "$CUSTOM"
chmod +x "$CUSTOM"

python3 - "$CUSTOM" <<'PY'
from pathlib import Path
import re,sys
p=Path(sys.argv[1])
s=p.read_text() if p.exists() else ""
for a,b in [
("# WLED_MARQUEE_V14_BEGIN","# WLED_MARQUEE_V14_END"),
("# USB_HUB75_MARQUEE_V20_BEGIN","# USB_HUB75_MARQUEE_V20_END"),
("# ZEDMD_MARQUEE_V30_BEGIN","# ZEDMD_MARQUEE_V30_END"),
("# ZEDMD_ANIMATIONS_V32_BEGIN","# ZEDMD_ANIMATIONS_V32_END")]:
    s=re.sub(r'\n?'+re.escape(a)+r'\n.*?'+re.escape(b)+r'\n?','\n',s,flags=re.S)
p.write_text(s.rstrip()+"\n")
PY

cat >> "$CUSTOM" <<'EOF'

# ZEDMD_MARQUEE_V30_BEGIN
# Known-working v3.0: check Pixelcade artwork once per boot after 30 seconds.
if [ -x /userdata/system/zedmd-marquee/artwork-update.sh ]; then
  /userdata/system/zedmd-marquee/artwork-update.sh --boot >/dev/null 2>&1 &
fi
# ZEDMD_MARQUEE_V30_END

# ZEDMD_ANIMATIONS_V32_BEGIN
# Known-working v3.2.1: random local startup GIF after dmd_real starts.
if [ "$1" = "start" ] && [ -x /userdata/system/zedmd-marquee/startup-random.sh ]; then
  /userdata/system/zedmd-marquee/startup-random.sh >/dev/null 2>&1 &
fi
# ZEDMD_ANIMATIONS_V32_END
EOF

echo
echo "===================================================="
echo " INSTALL COMPLETE"
echo "===================================================="
echo
echo "IMPORTANT: REBOOT BATOCERA NOW."
echo
echo "The original working setup did not begin displaying"
echo "marquees correctly until after a full reboot."
echo
echo "Run:"
echo "  reboot"
echo
echo "After reboot, diagnostics are:"
echo "  $BASE/diagnose.sh"
echo "  $BASE/diagnose-animations.sh"
