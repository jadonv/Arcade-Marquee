#!/bin/bash
BASE="/userdata/system/zedmd-marquee"
PATHFILE="$BASE/shutdown-gif.path"

[ -f "$PATHFILE" ] || exit 0
GIF="$(cat "$PATHFILE")"
[ -f "$GIF" ] || exit 0
command -v dmd-play >/dev/null 2>&1 || exit 0

echo "[$(date '+%F %T')] Shutdown: $GIF" >> "$BASE/animation.log"

# --once blocks until the GIF has played once, so Batocera waits for it
# before continuing shutdown.
dmd-play --file "$GIF" --once >/dev/null 2>&1 || true
