#!/bin/bash
BASE="/userdata/system/zedmd-marquee"
. "$BASE/animation-lib.sh"

echo "=== dmd-play ==="
command -v dmd-play || true
echo
echo "=== Animation roots ==="
animation_roots || true
echo
echo "=== GIF counts ==="
while IFS= read -r R; do
  printf '%s: ' "$R"
  find "$R" -maxdepth 1 -type f -iname '*.gif' 2>/dev/null | wc -l
done < <(animation_roots)
echo
echo "=== Screensaver ==="
ls -l /userdata/system/dmd/screensaver.gif 2>/dev/null || true
echo
echo "=== Shutdown ==="
cat "$BASE/shutdown-gif.path" 2>/dev/null || true
echo
echo "=== Matches ==="
echo -n "Dr Mario: "
find_first_for_key screensaver_patterns || echo NOT FOUND
echo -n "Shutdown: "
find_first_for_key shutdown_patterns || echo NOT FOUND
