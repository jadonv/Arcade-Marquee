#!/bin/bash
set -u
BASE="/userdata/system/zedmd-marquee"
. "$BASE/animation-lib.sh"

DELAY="$(getcfg startup_delay_seconds 6)"
ENABLED="$(getcfg startup_random true)"
case "$ENABLED" in true|True|1) ;; *) exit 0 ;; esac

sleep "$DELAY"

command -v dmd-play >/dev/null 2>&1 || exit 0
GIF="$(random_animation || true)"
[ -n "$GIF" ] || exit 0

echo "[$(date '+%F %T')] Startup random: $GIF" >> "$BASE/animation.log"

# Play twice total: initial play + one repeat, using the same random GIF.
dmd-play --file "$GIF" --once >/dev/null 2>&1 || true
dmd-play --file "$GIF" --once >/dev/null 2>&1 || true
