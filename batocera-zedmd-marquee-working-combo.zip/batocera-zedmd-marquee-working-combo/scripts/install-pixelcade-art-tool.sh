#!/bin/bash
set -u

BASE="/userdata/system/wled-marquee"
TOOLS="$BASE/tools"
BIN="$TOOLS/pixelweb"
LOG="$BASE/artwork-update.log"

mkdir -p "$TOOLS"

log() {
  echo "[$(date '+%F %T')] $*" | tee -a "$LOG"
}

ARCH="$(uname -m)"
case "$ARCH" in
  x86_64|amd64)
    PIXELCADE_ARCH="amd64"
    ;;
  i386|i486|i586|i686|x86)
    PIXELCADE_ARCH="386"
    ;;
  aarch64|arm64)
    PIXELCADE_ARCH="arm64"
    ;;
  armv7l|armv7*)
    PIXELCADE_ARCH="arm_v7"
    ;;
  armv6l|armv6*)
    PIXELCADE_ARCH="arm_v6"
    ;;
  *)
    log "ERROR: Unsupported architecture: $ARCH"
    exit 1
    ;;
esac

URL="https://github.com/alinke/pixelcade-linux-builds/raw/main/linux_${PIXELCADE_ARCH}/pixelweb"
TMP="$BIN.download"

log "Installing Pixelcade artwork utility for linux_${PIXELCADE_ARCH}..."
rm -f "$TMP"

if command -v curl >/dev/null 2>&1; then
  if ! curl -fL --connect-timeout 15 --retry 3 -o "$TMP" "$URL"; then
    log "ERROR: Could not download pixelweb."
    rm -f "$TMP"
    exit 1
  fi
elif command -v wget >/dev/null 2>&1; then
  if ! wget -O "$TMP" "$URL"; then
    log "ERROR: Could not download pixelweb."
    rm -f "$TMP"
    exit 1
  fi
else
  log "ERROR: Neither curl nor wget is installed."
  exit 1
fi

chmod +x "$TMP"

# Basic sanity check: Pixelcade's current binary supports -check-artwork.
if ! "$TMP" -h 2>&1 | grep -q "check-artwork"; then
  log "ERROR: Downloaded binary did not expose the expected artwork commands."
  rm -f "$TMP"
  exit 1
fi

mv -f "$TMP" "$BIN"
chmod +x "$BIN"
log "Pixelcade artwork utility installed: $BIN"
"$BIN" -version 2>&1 | tee -a "$LOG" || true
