#!/bin/bash
set -u
BASE=/userdata/system/zedmd-marquee
CFG="$BASE/config.json"
getcfg(){ python3 - "$CFG" "$1" "$2" <<'PY'
import json,sys
try: print(json.load(open(sys.argv[1])).get(sys.argv[2],sys.argv[3]))
except: print(sys.argv[3])
PY
}
ART="$(getcfg pixelcade_art_root /userdata/system/wled-marquee/pixelcade-art)"
GAMES="$(getcfg dmd_games_root /userdata/system/dmd/games)"
SYSTEMS="$(getcfg dmd_systems_root /userdata/system/dmd/systems)"
MARK="$BASE/.last-art-sync"
[ -d "$ART" ] || exit 0
mkdir -p "$GAMES" "$SYSTEMS"

if [ -f "$ART/.alinke_pixelcade-master-version" ]; then CUR="$(cat "$ART/.alinke_pixelcade-master-version")"
else CUR="$(stat -c %Y "$ART" 2>/dev/null || echo unknown)"; fi
[ "${1:-}" != "--updated" ] && [ -f "$MARK" ] && [ "$(cat "$MARK")" = "$CUR" ] && exit 0

if [ -d "$ART/system" ]; then
  find "$ART/system" -maxdepth 1 -type f \( -iname '*.png' -o -iname '*.gif' -o -iname '*.jpg' -o -iname '*.jpeg' \) -print0 |
  while IFS= read -r -d '' src; do
    dst="$SYSTEMS/$(basename "$src")"
    if [ ! -e "$dst" ] || [ -L "$dst" ]; then ln -sfn "$src" "$dst"; fi
  done
fi

find "$ART" -mindepth 1 -maxdepth 1 -type d -print0 |
while IFS= read -r -d '' dir; do
  sys="$(basename "$dir")"; [ "$sys" = system ] && continue
  mkdir -p "$GAMES/$sys"
  find "$dir" -maxdepth 1 -type f \( -iname '*.png' -o -iname '*.gif' -o -iname '*.jpg' -o -iname '*.jpeg' \) -print0 |
  while IFS= read -r -d '' src; do
    dst="$GAMES/$sys/$(basename "$src")"
    if [ ! -e "$dst" ] || [ -L "$dst" ]; then ln -sfn "$src" "$dst"; fi
  done
done
printf '%s' "$CUR" > "$MARK"
