#!/bin/bash
set -u
BASE="/userdata/system/zedmd-marquee"
CFG="$BASE/config.json"

getcfg() {
  python3 - "$CFG" "$1" "$2" <<'PY'
import json,sys
try:
    print(json.load(open(sys.argv[1])).get(sys.argv[2],sys.argv[3]))
except Exception:
    print(sys.argv[3])
PY
}

animation_roots() {
  local art user
  art="$(getcfg pixelcade_art_root /userdata/system/wled-marquee/pixelcade-art)"
  user="$(getcfg user_animation_root /userdata/system/zedmd-marquee/user-animations)"
  [ -d "$art/animated" ] && printf '%s\n' "$art/animated"
  [ -d "$art/animations" ] && printf '%s\n' "$art/animations"
  [ -d "$user" ] && printf '%s\n' "$user"
}

find_pattern() {
  local pattern="$1" root hit
  while IFS= read -r root; do
    [ -d "$root" ] || continue
    hit="$(find "$root" -maxdepth 1 -type f -iname "$pattern" -print -quit 2>/dev/null)"
    if [ -n "$hit" ]; then
      printf '%s\n' "$hit"
      return 0
    fi
  done < <(animation_roots)
  return 1
}

patterns_for_key() {
  python3 - "$CFG" "$1" <<'PY'
import json,sys
try:
    for p in json.load(open(sys.argv[1])).get(sys.argv[2],[]):
        print(p)
except Exception:
    pass
PY
}

find_first_for_key() {
  local key="$1" pattern hit
  while IFS= read -r pattern; do
    [ -n "$pattern" ] || continue
    hit="$(find_pattern "$pattern" || true)"
    if [ -n "$hit" ]; then
      printf '%s\n' "$hit"
      return 0
    fi
  done < <(patterns_for_key "$key")
  return 1
}

random_animation() {
  local tmp root count
  tmp="$(mktemp)"
  while IFS= read -r root; do
    [ -d "$root" ] || continue
    find "$root" -maxdepth 1 -type f -iname '*.gif' -print >> "$tmp" 2>/dev/null
  done < <(animation_roots)
  count="$(wc -l < "$tmp" | tr -d ' ')"
  if [ "${count:-0}" -gt 0 ]; then
    shuf -n 1 "$tmp" 2>/dev/null || awk 'BEGIN{srand()} {a[NR]=$0} END{if(NR) print a[1+int(rand()*NR)]}' "$tmp"
  fi
  rm -f "$tmp"
}
