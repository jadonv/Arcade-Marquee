#!/bin/bash
set -u
BASE=/userdata/system/zedmd-marquee
LEGACY=/userdata/system/wled-marquee
CFG="$BASE/config.json"
BIN="$LEGACY/tools/pixelweb"
LOG="$BASE/artwork-update.log"
mkdir -p "$BASE" "$LEGACY/tools"
getcfg(){ python3 - "$CFG" "$1" "$2" <<'PY'
import json,sys
try: print(json.load(open(sys.argv[1])).get(sys.argv[2],sys.argv[3]))
except: print(sys.argv[3])
PY
}
ART="$(getcfg pixelcade_art_root /userdata/system/wled-marquee/pixelcade-art)"
DELAY="$(getcfg pixelcade_boot_delay_seconds 30)"
MODE="${1:---check}"
[ "$MODE" = "--boot" ] && sleep "$DELAY"

if [ ! -x "$BIN" ]; then
  cp -f "$BASE/install-pixelcade-art-tool.sh" "$LEGACY/install-pixelcade-art-tool.sh"
  chmod +x "$LEGACY/install-pixelcade-art-tool.sh"
  "$LEGACY/install-pixelcade-art-tool.sh" || exit 0
fi
mkdir -p "$ART"

UPDATED=0
if [ ! -d "$ART/mame" ] && [ ! -f "$ART/.alinke_pixelcade-master-version" ]; then
  "$BIN" -p "$ART" -install-artwork -progress-stdout 2>&1 | tee -a "$LOG"; UPDATED=1
elif [ "$MODE" = "--force-update" ]; then
  "$BIN" -p "$ART" -update-artwork -progress-stdout 2>&1 | tee -a "$LOG"; UPDATED=1
else
  "$BIN" -p "$ART" -check-artwork >>"$LOG" 2>&1
  RC=$?
  if [ "$RC" -eq 1 ]; then
    "$BIN" -p "$ART" -update-artwork -progress-stdout 2>&1 | tee -a "$LOG"; UPDATED=1
  elif [ "$RC" -eq 2 ]; then
    "$BIN" -p "$ART" -install-artwork -progress-stdout 2>&1 | tee -a "$LOG"; UPDATED=1
  fi
fi
[ "$UPDATED" -eq 1 ] && "$BASE/sync-artwork.sh" --updated || "$BASE/sync-artwork.sh"
