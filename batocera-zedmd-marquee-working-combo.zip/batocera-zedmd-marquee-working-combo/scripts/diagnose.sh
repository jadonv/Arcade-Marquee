#!/bin/bash
echo "=== Batocera ==="; batocera-version 2>/dev/null || true
echo; echo "=== Serial ==="; ls -l /dev/ttyUSB* /dev/ttyACM* 2>/dev/null || true
echo; echo "=== dmd_real ==="; batocera-services status dmd_real 2>/dev/null || true
echo; echo "=== ZeDMD ==="
batocera-services stop dmd_real 2>/dev/null || true; sleep 1
command -v zedmd-client >/dev/null 2>&1 && zedmd-client -i || true
batocera-services start dmd_real 2>/dev/null || true
echo; echo "=== Linked Pixelcade artwork ==="
echo -n "Games: "; find /userdata/system/dmd/games -type l 2>/dev/null | wc -l
echo -n "Systems: "; find /userdata/system/dmd/systems -type l 2>/dev/null | wc -l
