#!/bin/bash
set -u
batocera-services stop dmd_real 2>/dev/null || true
sleep 1
if command -v zedmd-client >/dev/null 2>&1; then
  zedmd-client -i || true
  zedmd-client --set-usb-package-size=512 || true
  zedmd-client --set-panel-min-refresh-rate=60 || true
  zedmd-client -i || true
else
  echo "zedmd-client not found; Batocera 42+ normally includes it."
fi
batocera-services start dmd_real 2>/dev/null || true
