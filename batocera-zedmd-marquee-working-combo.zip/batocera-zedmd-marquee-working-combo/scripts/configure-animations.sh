#!/bin/bash
set -u
BASE="/userdata/system/zedmd-marquee"
. "$BASE/animation-lib.sh"

mkdir -p /userdata/system/dmd

SCREEN="$(find_first_for_key screensaver_patterns || true)"
SHUT="$(find_first_for_key shutdown_patterns || true)"

if [ -n "$SCREEN" ]; then
  ln -sfn "$SCREEN" /userdata/system/dmd/screensaver.gif
  echo "Screensaver GIF: $SCREEN"
else
  echo "WARNING: Dr. Mario GIF not found."
  echo "Checked local Pixelcade animated/animations folders and:"
  echo "  /userdata/system/zedmd-marquee/user-animations"
fi

if [ -n "$SHUT" ]; then
  printf '%s\n' "$SHUT" > "$BASE/shutdown-gif.path"
  echo "Shutdown GIF: $SHUT"
else
  rm -f "$BASE/shutdown-gif.path"
  echo "WARNING: supermarioallstartheend.gif not found."
fi

echo
echo "Animation roots:"
animation_roots | sed 's/^/  /'
