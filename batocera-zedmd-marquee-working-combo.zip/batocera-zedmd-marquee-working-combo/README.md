# Batocera ZeDMD Marquee — Known Working Combo

This package combines the **actual working scripts** from:

- `batocera-zedmd-marquee-v3.0`
- `batocera-zedmd-marquee-v3.2.1`

The ESP32 firmware flash is intentionally kept in a **separate package**.

No v4.x scripts, custom boot firmware, PlatformIO build, Git requirement, or experimental firmware are included.

## Install Order

```text
1. Flash package
   ↓
Official ZeDMD 5.1.7 / 128×32
   ↓
Exit ZeDMD setup screen with Transport = USB
   ↓
2. This combined Batocera package
   ↓
v3.0 base setup
   +
v3.2.1 animation setup
   ↓
REBOOT — REQUIRED
   ↓
Done
```

# Hardware

- ESP32-WROOM-32 / WROOM-32U
- 2 × 64×32 P4 HUB75 panels
- 1 row × 2 columns
- Total display: **128×32**
- USB transport to Batocera

## ZeDMD HUB75 Pinout

| HUB75 | ESP32 GPIO |
|---|---:|
| R1 | 25 |
| G1 | 26 |
| B1 | 27 |
| R2 | 14 |
| G2 | 12 |
| B2 | 13 |
| A | 23 |
| B | 19 |
| C | 5 |
| D | 17 |
| E | 22 — leave disconnected for these 64×32 1/16 panels |
| CLK | 16 |
| LAT / STROBE | 4 |
| OE | 15 |
| GND | ESP32 GND |

## Power

```text
AC Live    -> PSU L
AC Neutral -> PSU N
AC Ground  -> PSU Earth

PSU V+ -> red power lead on Panel 1
PSU V+ -> red power lead on Panel 2

PSU V- -> black power lead on Panel 1
PSU V- -> black power lead on Panel 2
PSU V- -> ESP32 GND (common ground)
```

The HUB75 ribbon is the data connection. The panels receive their 5 V power through their red/black power leads.

# What the Combined Installer Does

The installer reproduces the working v3.0 base setup **without reflashing firmware**, then applies the working v3.2.1 animation layer.

It:

1. Removes the older custom WLED/USB marquee hooks.
2. Installs the Pixelcade `pixelweb` artwork utility if it is not already present.
3. Downloads the Pixelcade artwork library if it is not already installed.
4. Checks the artwork library for updates.
5. Links Pixelcade artwork into Batocera's native DMD artwork paths.
6. Enables and starts Batocera `dmd_real`.
7. Applies the known-working ZeDMD settings:
   - USB packet size: **512**
   - minimum panel refresh: **60 Hz**
8. Installs the v3.2.1 animation scripts.
9. Finds/configures the Dr. Mario screensaver GIF.
10. Finds/configures `supermarioallstartheend.gif` for shutdown.
11. Adds the random startup GIF behavior.
12. Adds the once-per-boot artwork check.
13. Requires a full reboot before judging whether the installation worked.

# Dependencies

Expected on the Batocera system:

- Batocera 42+
- `python3`
- `curl` or `wget`
- `unzip`
- `dmd_real`
- `dmd-play`
- `zedmd-client`
- network access for the initial Pixelcade artwork/tool download
- already-flashed ZeDMD 5.1.7 ESP32

You do **not** need:

- Git
- PlatformIO
- WLED
- ESP32 Wi-Fi

# Install

Copy the ZIP into the Batocera `share` folder.

SSH into Batocera:

```bash
cd /userdata
unzip -o batocera-zedmd-marquee-working-combo.zip
cd batocera-zedmd-marquee-working-combo
chmod +x install.sh scripts/*.sh
./install.sh
```

## Reboot — Required

After the installer finishes:

```bash
reboot
```

**Do not troubleshoot a failed marquee connection before doing this reboot.**

During the original working installation, the ESP32 was visible at `/dev/ttyUSB0` but the marquee did not begin operating correctly until Batocera was fully restarted.

# What Happens on Boot

The v3.0 artwork updater runs once per boot after **30 seconds**.

It checks the existing Pixelcade artwork version. If artwork is missing it installs it; if an update is reported it updates it; otherwise it leaves the library alone.

The v3.2.1 startup animation waits **6 seconds**, chooses one random local GIF, and plays the **same GIF twice total**.

# Artwork Paths

Pixelcade source artwork:

```text
/userdata/system/wled-marquee/pixelcade-art
```

Batocera native system links:

```text
/userdata/system/dmd/systems
```

Batocera native game links:

```text
/userdata/system/dmd/games
```

User animation folder:

```text
/userdata/system/zedmd-marquee/user-animations
```

# Screensaver

v3.2.1 searches for:

```text
drnario.gif
drmario.gif
*dr*mario*.gif
*doctor*mario*.gif
```

The match is linked to:

```text
/userdata/system/dmd/screensaver.gif
```

# Shutdown

v3.2.1 searches for:

```text
supermarioallstartheend.gif
*super*mario*all*star*the*end*.gif
*mario*the*end*.gif
```

The selected GIF is played once through `dmd-play --once` by the Batocera `shutdown` and `quit` hooks.

# Diagnostics

After the required reboot:

```bash
/userdata/system/zedmd-marquee/diagnose.sh
```

Animation diagnostics:

```bash
/userdata/system/zedmd-marquee/diagnose-animations.sh
```

Direct ZeDMD information:

```bash
batocera-services stop dmd_real
zedmd-client -i
batocera-services start dmd_real
```

Expected controller basics:

```text
Firmware: 5.1.7
CPU: ESP32
Transport: USB
Device: /dev/ttyUSB0
Panel: 128×32
USB packet size: 512
Minimum refresh: 60 Hz
```

# Manual Artwork Update

Check/update:

```bash
/userdata/system/zedmd-marquee/artwork-update.sh --check
```

Force update:

```bash
/userdata/system/zedmd-marquee/artwork-update.sh --force-update
```

Refresh Batocera artwork links:

```bash
/userdata/system/zedmd-marquee/sync-artwork.sh --updated
```

# Re-detect Animation Files

```bash
/userdata/system/zedmd-marquee/configure-animations.sh
```

# Final Working Stack

```text
Official ZeDMD 5.1.7 firmware
        ↓
USB / 128×32
        ↓
Batocera dmd_real
        ↓
v3.0 artwork/update/sync scripts
        +
v3.2.1 animation/event scripts
        ↓
2 × 64×32 P4 HUB75 panels
```
