Place GIFs you have rights to use here if they are not already in your local artwork folders.
The installer copies them to /userdata/system/zedmd-marquee/user-animations/.
